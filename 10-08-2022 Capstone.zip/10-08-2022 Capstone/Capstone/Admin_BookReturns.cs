﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Capstone
{
    public partial class Admin_BookReturns : Form
    {
        public static String BKBR_ID = "";
        public static String UID = "";
        public static String BookTitle = "";
        public static String AccNo = "";
        public static String Author = "";
        public static String DateBorrowed = "";
        public static String DueDate = "";
        public static String NotedBy = "";
        public static String StaffUsername = "";

        List<BookReturnsInfo> br = new List<BookReturnsInfo>();
        List<getBRColumn> c = new List<getBRColumn>();
        SQLBookReturnsCommands sql = new SQLBookReturnsCommands();
        public Admin_BookReturns()
        {
            InitializeComponent();
        }

        private void Admin_BookReturns_Load(object sender, EventArgs e)
        {
            UpdateBinding();
            ComboBoxSel();  
        }
        public void UpdateBinding() {
            br = sql.LoadBookReturnsData();
            dgv_bookreturns.DataSource = br;
        }
        public void ComboBoxSel() {
            c = sql.LoadSearchCriteria();
            cmbcriteria.DataSource = c;
            cmbcriteria.DisplayMember = "name";

            c = sql.LoadisPaid();
            selpaid.DataSource = c;
            selpaid.DisplayMember = "isPaid";
            selpaid.SelectedIndex = 0;

            c = sql.LoadBKReturnsRemarks();
            bkret_remarks_cmb.DataSource = c;
            bkret_remarks_cmb.DisplayMember = "BKReturnsRemarks";
            bkret_remarks_cmb.SelectedIndex = 0;
        }
        public void clear() { 
        
        }
        private void searchbtn_Click(object sender, EventArgs e)
        {
            if (cmbcriteria.Text.Equals("")) { }
            else if (cmbcriteria.Text.Equals("")) { }
            else if (cmbcriteria.Text.Equals("")) { }
            else if (cmbcriteria.Text.Equals("")) { }
            else if (cmbcriteria.Text.Equals("")) { }
            else if (cmbcriteria.Text.Equals("")) { }
        }

        private void insertbtn_Click(object sender, EventArgs e)
        {
            //get current employee username, real name, and employee id
        }

        private void updbtn_Click(object sender, EventArgs e)
        {

        }

        private void delbtn_Click(object sender, EventArgs e)
        {

        }

        private void clrbtn_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void cmbcriteria_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateBinding();
            if (cmbcriteria.Text.Equals("Date_Borrowed"))
            {
                MessageBox.Show("When searching for a particular date on this criteria, please follow the format below on your search keywords:" +
                    "\n\n(yyyy-mm-dd) or (yyyy/mm/dd)", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else if (cmbcriteria.Text.Equals("DueDate"))
            {
                MessageBox.Show("When searching for a particular date on this criteria, please follow the format below on your search keywords:" +
                    "\n\n(yyyy-mm-dd) or (yyyy/mm/dd)", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (cmbcriteria.Text.Equals("ReturnedOn"))
            {
                MessageBox.Show("When searching on this criteria, please enter only numerical characters on your search keywords.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dgv_bookreturns_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            bkr_timer.Enabled = false;
            try {

                if (dgv_bookreturns.SelectedRows.Count >= 0) {

                    DataGridViewRow row = this.dgv_bookreturns.Rows[e.RowIndex];
                    //txtbox.Text = row.Cells["ID"].Value.ToString();

                    /*
                    get bkbr ref id
                    get bkreturns remarks id
                    get ispaid id
                    */

                    updbtn.Enabled = true;
                    delbtn.Enabled = true;
                }
            }
            catch (Exception) { }
        }

        private void bkr_timer_Tick(object sender, EventArgs e)
        {
            SQLBookBorrowingCommands u = new SQLBookBorrowingCommands();
            SQLBookReturnsCommands bkr = new SQLBookReturnsCommands();

            //if (BKBR_ID.Length == 0 && UID.Length == 0 && BookTitle.Length == 0 && AccNo.Length == 0 && Author.Length == 0 && DateBorrowed.Length == 0 && DueDate.Length == 0) { }
            //else if (BKBR_ID.Length > 0 && UID.Length > 0 && BookTitle.Length > 0 && AccNo.Length > 0 && Author.Length > 0 && DateBorrowed.Length > 0 && DueDate.Length > 0) {
                bkr_timer.Start();
                bkbr_id.Text = BKBR_ID;
                uid.Text = UID;
                bktitle.Text = BookTitle;
                accno.Text = AccNo;
                bkaut.Text = Author;
                dtborrowed.Text = DateBorrowed;
                duedt.Text = DueDate;
                if (bkbr_id.Text.Length == 0) {
                    bkbr_id.Text = "[ID]";
                }
            //}

            if (NotedBy.Length == 0 && StaffUsername.Length == 0) { }
            else if (NotedBy.Length > 0 && StaffUsername.Length > 0)
            {
                bkr_timer.Start();
                empname.Text = NotedBy;
                un.Text = StaffUsername;
                un_id.Text = u.getEmployeeID(un.Text);
                if (un_id.Text.Length == 0) { 
                    un_id.Text = "[ID]";
                }
            }
        }

        private void sel_staff_Click(object sender, EventArgs e)
        {
            bkr_timer.Start();
            BKBR_SelectStaffUsername b = new BKBR_SelectStaffUsername();
            b.Show();
        }

        private void bkret_remarks_cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            bkret_remarks_cmb_id.Text = sql.getBKRetRem_id(bkret_remarks_cmb.Text);
        }

        private void selpaid_SelectedIndexChanged(object sender, EventArgs e)
        {
            paid_id.Text = sql.get_isPaid_id(selpaid.Text);
        }

        private void btn_bkbrinfo_Click(object sender, EventArgs e)
        {
            bkr_timer.Start();
            BKR_SelectBKBR_Info b = new BKR_SelectBKBR_Info();
            b.Show();
        }

        private void refbtn_Click(object sender, EventArgs e)
        {
            UpdateBinding();
        }
    }
}
