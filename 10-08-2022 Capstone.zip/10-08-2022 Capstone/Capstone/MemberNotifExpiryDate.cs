﻿using System;

namespace Capstone
{
    public class MemberNotifExpiryDate
    {
        public String NotificationMsg { get; set; }
        public String DatePosted { get; set; }
    }
}
