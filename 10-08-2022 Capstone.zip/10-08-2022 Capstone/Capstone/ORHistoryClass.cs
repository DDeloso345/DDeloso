﻿using System;

namespace Capstone
{
    public class ORHistoryClass
    {
        public int id { get; set; }
        public String COCPL_UID { get; set; }
        public String FirstName { get; set; }
        public String MiddleName { get; set; }
        public String LastName { get; set; }
        public String ORNumber { get; set; }
        public String ORReceivedDate { get; set; }
    }
}
