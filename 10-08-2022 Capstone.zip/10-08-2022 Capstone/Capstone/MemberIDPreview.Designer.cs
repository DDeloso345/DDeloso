﻿
namespace Capstone
{
    partial class MemberIDPreview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.membidpnl = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.selectmemberimg = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.endtxt = new System.Windows.Forms.Label();
            this.starttxt = new System.Windows.Forms.Label();
            this.numbtxt = new System.Windows.Forms.Label();
            this.emailtxt = new System.Windows.Forms.Label();
            this.addtxt = new System.Windows.Forms.Label();
            this.orgtxt = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.uidtxt = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.mnlbl = new System.Windows.Forms.Label();
            this.fnlbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lnlbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.citysealimg = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.membidpnl.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.selectmemberimg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.citysealimg)).BeginInit();
            this.SuspendLayout();
            // 
            // membidpnl
            // 
            this.membidpnl.Controls.Add(this.panel2);
            this.membidpnl.Controls.Add(this.pictureBox5);
            this.membidpnl.Controls.Add(this.label12);
            this.membidpnl.Controls.Add(this.pictureBox3);
            this.membidpnl.Controls.Add(this.pictureBox4);
            this.membidpnl.Controls.Add(this.pictureBox2);
            this.membidpnl.Controls.Add(this.endtxt);
            this.membidpnl.Controls.Add(this.starttxt);
            this.membidpnl.Controls.Add(this.numbtxt);
            this.membidpnl.Controls.Add(this.emailtxt);
            this.membidpnl.Controls.Add(this.addtxt);
            this.membidpnl.Controls.Add(this.orgtxt);
            this.membidpnl.Controls.Add(this.label11);
            this.membidpnl.Controls.Add(this.label10);
            this.membidpnl.Controls.Add(this.label9);
            this.membidpnl.Controls.Add(this.label8);
            this.membidpnl.Controls.Add(this.label7);
            this.membidpnl.Controls.Add(this.label6);
            this.membidpnl.Controls.Add(this.uidtxt);
            this.membidpnl.Controls.Add(this.label5);
            this.membidpnl.Controls.Add(this.mnlbl);
            this.membidpnl.Controls.Add(this.fnlbl);
            this.membidpnl.Controls.Add(this.pictureBox1);
            this.membidpnl.Controls.Add(this.lnlbl);
            this.membidpnl.Controls.Add(this.label4);
            this.membidpnl.Controls.Add(this.label3);
            this.membidpnl.Controls.Add(this.label2);
            this.membidpnl.Controls.Add(this.citysealimg);
            this.membidpnl.Controls.Add(this.label1);
            this.membidpnl.Location = new System.Drawing.Point(3, 2);
            this.membidpnl.Name = "membidpnl";
            this.membidpnl.Size = new System.Drawing.Size(780, 425);
            this.membidpnl.TabIndex = 12;
            this.membidpnl.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.selectmemberimg);
            this.panel2.Location = new System.Drawing.Point(1, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 200);
            this.panel2.TabIndex = 42;
            // 
            // selectmemberimg
            // 
            this.selectmemberimg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.selectmemberimg.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.selectmemberimg.Location = new System.Drawing.Point(10, 10);
            this.selectmemberimg.Name = "selectmemberimg";
            this.selectmemberimg.Size = new System.Drawing.Size(180, 180);
            this.selectmemberimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.selectmemberimg.TabIndex = 13;
            this.selectmemberimg.TabStop = false;
            this.selectmemberimg.Click += new System.EventHandler(this.selectmemberimg_Click_1);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox5.Location = new System.Drawing.Point(460, 396);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(300, 2);
            this.pictureBox5.TabIndex = 41;
            this.pictureBox5.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(457, 401);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(313, 16);
            this.label12.TabIndex = 40;
            this.label12.Text = "PRINTED NAME AND SIGNATURE OF AUTHORIZED STAFF";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox3.Location = new System.Drawing.Point(20, 355);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(740, 2);
            this.pictureBox3.TabIndex = 39;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox4.Location = new System.Drawing.Point(399, 206);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(2, 150);
            this.pictureBox4.TabIndex = 38;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox2.Location = new System.Drawing.Point(15, 206);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(740, 2);
            this.pictureBox2.TabIndex = 36;
            this.pictureBox2.TabStop = false;
            // 
            // endtxt
            // 
            this.endtxt.AutoSize = true;
            this.endtxt.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endtxt.Location = new System.Drawing.Point(654, 316);
            this.endtxt.Name = "endtxt";
            this.endtxt.Size = new System.Drawing.Size(47, 18);
            this.endtxt.TabIndex = 35;
            this.endtxt.Text = "label5";
            // 
            // starttxt
            // 
            this.starttxt.AutoSize = true;
            this.starttxt.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.starttxt.Location = new System.Drawing.Point(654, 276);
            this.starttxt.Name = "starttxt";
            this.starttxt.Size = new System.Drawing.Size(47, 18);
            this.starttxt.TabIndex = 34;
            this.starttxt.Text = "label5";
            // 
            // numbtxt
            // 
            this.numbtxt.AutoSize = true;
            this.numbtxt.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numbtxt.Location = new System.Drawing.Point(654, 235);
            this.numbtxt.Name = "numbtxt";
            this.numbtxt.Size = new System.Drawing.Size(47, 18);
            this.numbtxt.TabIndex = 33;
            this.numbtxt.Text = "label5";
            this.numbtxt.Click += new System.EventHandler(this.numbtxt_Click);
            // 
            // emailtxt
            // 
            this.emailtxt.AutoSize = true;
            this.emailtxt.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailtxt.Location = new System.Drawing.Point(213, 317);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(47, 18);
            this.emailtxt.TabIndex = 32;
            this.emailtxt.Text = "label5";
            // 
            // addtxt
            // 
            this.addtxt.AutoSize = true;
            this.addtxt.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addtxt.Location = new System.Drawing.Point(121, 268);
            this.addtxt.Name = "addtxt";
            this.addtxt.Size = new System.Drawing.Size(47, 18);
            this.addtxt.TabIndex = 31;
            this.addtxt.Text = "label5";
            this.addtxt.Click += new System.EventHandler(this.addtxt_Click);
            // 
            // orgtxt
            // 
            this.orgtxt.AutoSize = true;
            this.orgtxt.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orgtxt.Location = new System.Drawing.Point(213, 235);
            this.orgtxt.Name = "orgtxt";
            this.orgtxt.Size = new System.Drawing.Size(47, 18);
            this.orgtxt.TabIndex = 30;
            this.orgtxt.Text = "label5";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(411, 316);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(209, 19);
            this.label11.TabIndex = 29;
            this.label11.Text = "END OF MEMBERSHIP:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(411, 275);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(231, 19);
            this.label10.TabIndex = 28;
            this.label10.Text = "START OF MEMBERSHIP:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(411, 234);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(180, 19);
            this.label9.TabIndex = 27;
            this.label9.Text = "CONTACT NUMBER:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(18, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(166, 19);
            this.label8.TabIndex = 26;
            this.label8.Text = "E-MAIL ADDRESS:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 19);
            this.label7.TabIndex = 25;
            this.label7.Text = "ADDRESS:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(18, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 19);
            this.label6.TabIndex = 24;
            this.label6.Text = "ORGANIZATION:";
            // 
            // uidtxt
            // 
            this.uidtxt.AutoSize = true;
            this.uidtxt.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uidtxt.Location = new System.Drawing.Point(324, 78);
            this.uidtxt.Name = "uidtxt";
            this.uidtxt.Size = new System.Drawing.Size(57, 20);
            this.uidtxt.TabIndex = 23;
            this.uidtxt.Text = "label5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(212, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 19);
            this.label5.TabIndex = 22;
            this.label5.Text = "COCPL UID:";
            // 
            // mnlbl
            // 
            this.mnlbl.AutoSize = true;
            this.mnlbl.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnlbl.Location = new System.Drawing.Point(581, 154);
            this.mnlbl.Name = "mnlbl";
            this.mnlbl.Size = new System.Drawing.Size(47, 18);
            this.mnlbl.TabIndex = 21;
            this.mnlbl.Text = "label7";
            // 
            // fnlbl
            // 
            this.fnlbl.AutoSize = true;
            this.fnlbl.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnlbl.Location = new System.Drawing.Point(415, 154);
            this.fnlbl.Name = "fnlbl";
            this.fnlbl.Size = new System.Drawing.Size(47, 18);
            this.fnlbl.TabIndex = 20;
            this.fnlbl.Text = "label6";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pictureBox1.Location = new System.Drawing.Point(213, 174);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(540, 2);
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // lnlbl
            // 
            this.lnlbl.AutoSize = true;
            this.lnlbl.Font = new System.Drawing.Font("Bookman Old Style", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnlbl.Location = new System.Drawing.Point(247, 151);
            this.lnlbl.Name = "lnlbl";
            this.lnlbl.Size = new System.Drawing.Size(47, 18);
            this.lnlbl.TabIndex = 18;
            this.lnlbl.Text = "label5";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(581, 179);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 19);
            this.label4.TabIndex = 17;
            this.label4.Text = "MIDDLE NAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(415, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 19);
            this.label3.TabIndex = 16;
            this.label3.Text = "FIRST NAME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bookman Old Style", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(247, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 19);
            this.label2.TabIndex = 15;
            this.label2.Text = "LAST NAME";
            // 
            // citysealimg
            // 
            this.citysealimg.Image = global::Capstone.Properties.Resources.Cagayan_de_Oro_official_seal_2C_2014_png__77847__thumb;
            this.citysealimg.Location = new System.Drawing.Point(629, 10);
            this.citysealimg.Name = "citysealimg";
            this.citysealimg.Size = new System.Drawing.Size(126, 124);
            this.citysealimg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.citysealimg.TabIndex = 14;
            this.citysealimg.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bookman Old Style", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(199, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(432, 44);
            this.label1.TabIndex = 13;
            this.label1.Text = "CAGAYAN DE ORO CITY PUBLIC LIBRARY\r\nMEMBER\'S CARD";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // MemberIDPreview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.membidpnl);
            this.MaximumSize = new System.Drawing.Size(800, 500);
            this.Name = "MemberIDPreview";
            this.Text = "COCPL Member ID Preview";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MemberIDPreview_FormClosing);
            this.Load += new System.EventHandler(this.MemberIDPreview_Load);
            this.membidpnl.ResumeLayout(false);
            this.membidpnl.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.selectmemberimg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.citysealimg)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel membidpnl;
        private System.Windows.Forms.Label endtxt;
        private System.Windows.Forms.Label starttxt;
        private System.Windows.Forms.Label numbtxt;
        private System.Windows.Forms.Label emailtxt;
        private System.Windows.Forms.Label addtxt;
        private System.Windows.Forms.Label orgtxt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label uidtxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label mnlbl;
        private System.Windows.Forms.Label fnlbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lnlbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox citysealimg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox selectmemberimg;
    }
}