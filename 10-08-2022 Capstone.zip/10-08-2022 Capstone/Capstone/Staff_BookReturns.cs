﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Capstone
{
    public partial class Staff_BookReturns : Form
    {
        public static String BKBR_ID = "";
        public static String UID = "";
        public static String BookTitle = "";
        public static String AccNo = "";
        public static String Author = "";
        public static String DateBorrowed = "";
        public static String DueDate = "";
        public static String NotedBy = "";
        public static String StaffUsername = "";
        public Staff_BookReturns()
        {
            InitializeComponent();
        }

        private void Staff_BookReturns_Load(object sender, System.EventArgs e)
        {

        }
    }
}
