﻿using System;

namespace Capstone
{
    public class ORHistoryComboboxClass
    {

    }
    public class ORHColumnName
    {
        public String name { get; set; }
    }
}
