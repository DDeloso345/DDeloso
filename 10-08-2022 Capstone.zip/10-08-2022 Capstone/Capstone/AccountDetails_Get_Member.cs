﻿using System;

namespace Capstone
{
    public class AccountDetails_Get_Member
    {
        public int id { get; set; }
        public String COCPL_UID { get; set; }
        public String FirstName { get; set; }
        public String MiddleName { get; set; }
        public String LastName { get; set; }
        public String Suffix { get; set; }
        public String SchoolOrOrganization { get; set; }
        public String Address { get; set; }
        public String EMailAddress { get; set; }
        public String ContactNo { get; set; }
        public String MemberStart { get; set; }
        public String MemberEnd { get; set; }
        public String ImgPath { get; set; }
    }
}
