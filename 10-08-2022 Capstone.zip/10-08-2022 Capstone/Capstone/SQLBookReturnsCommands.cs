﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace Capstone
{
    public class SQLBookReturnsCommands
    {
        public List<BookReturnsInfo> LoadBookReturnsData()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<BookReturnsInfo>($"select *from [Book Returns]").ToList();
                return output;
            }
        }
        public List<getBRColumn> LoadSearchCriteria()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<getBRColumn>($"SELECT name FROM sys.columns WHERE OBJECT_ID = OBJECT_ID('Book Returns')").ToList();
                return output;
            }
        }
        public List<getBKBR_Ref_Info> LoadSelectBKBR_Ref_Info()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<getBKBR_Ref_Info>($"select *from [BKBR Reference to Book Returns]").ToList();
                return output;
            }
        }
        public List<getBRColumn> LoadSearchCmb_BKBR_RefInfo()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<getBRColumn>($"SELECT name FROM sys.columns WHERE OBJECT_ID = OBJECT_ID('BKBR Reference to Book Returns')").ToList();
                return output;
            }
        }
        public List<getBKBR_Ref_Info> SearchBKBR_Ref_Info(String crit, String inp)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<getBKBR_Ref_Info>($"select *from [BKBR Reference to Book Returns] where {crit} like '%{inp}%'").ToList();
                if (output.Count == 0)
                {
                    MessageBox.Show("The keywords that you have searched for yields no results.\nPlease try a different set of keywords.", "No results found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                return output;
            }
        }
        public String getID_BKBR_RefInfo(String id, String uid, String title, String accno, String aut, String dtb, String duedt)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                MessageBox.Show(dtb+"\n"+duedt);
                String a = dtb.Replace("/","-");
                String b = duedt.Replace("/","-");
                var output = Convert.ToString(connection.ExecuteScalar($"select id from [BKBR Reference to Book Returns] where id = '{id}' and COCPL_UID  = '{uid}' and BookTitle = '{title}' and AccessionNumber = '{accno}' and BookAuthor = '{aut}' and Date_Borrowed = '{a}' and DueDate = '{b}'"));
                return output;
            }
        }
        public List<getBRColumn> LoadisPaid()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<getBRColumn>($"SELECT isPaid from BKR_PaymentStatus").ToList();
                return output;
            }
        }
        public String get_isPaid_id(String inp) {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = Convert.ToString(connection.ExecuteScalar($"select id from BKR_PaymentStatus where isPaid = '{inp}'"));
                return output;
            }
        }
        public List<getBRColumn> LoadBKReturnsRemarks()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<getBRColumn>($"SELECT BKReturnsRemarks from BKReturnsRemarks").ToList();
                return output;
            }
        }
        public String getBKRetRem_id(String inp) {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = Convert.ToString(connection.ExecuteScalar($"select id from BKReturnsRemarks where BKReturnsRemarks = '{inp}'"));
                return output;
            }
        }
        public void InsertBKReturnsRecords()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                //insert bkreturns table
                //update bkinv bkinfo
                //update bkinv main
                //update bkbr table
                MessageBox.Show("The specified book returns record has been successfully added.", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void UpdateBKReturnsRecords()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                MessageBox.Show("The specified book returns record has been successfully updated.", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public void DeleteBKReturnsRecords()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                MessageBox.Show("The specified book returns record has been successfully deleted.", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        public List<BookReturnsInfo> SearchBookReturnsInfo(String crit, String inp)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<BookReturnsInfo>($"").ToList();
                return output;
            }
        }
        /*
        public List<BookReturnsInfo> LoadBKBorrowingInfo()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(SQLConnectionClass.ConnVal("lb_TestDB")))
            {
                var output = connection.Query<>($"").ToList();
                return output;
            }
        }
        */
    }
}
