use lb_TestDB

select *from employee_user_profile

create database testdb
use testdb
SELECT
  *FROM
  lb_testdb.INFORMATION_SCHEMA.TABLES
WHERE
  TABLE_TYPE = 'BASE TABLE';
GO

drop table archive_emp_info_main
drop table emp_info_main
drop table EmpInfo
drop table EmpRoles
drop table EmpStatus
drop table EmpPosition

create table author(id int identity (1,1) primary key, AuthorNumber varchar(50), Author varchar(50));
insert into author values('2314132','asdasd');
select *from author
drop table author

create table emp_info_main (id int identity (1,1) primary key, FirstName varchar(100), MiddleName varchar(100), LastName varchar(100), Position int, EmpRoles int, EMailAddress varchar(100), ContactNo varchar(11), username varchar(100), password varchar(100), ImgPath varchar(500), ActiveStatus varchar(10))
insert into emp_info_main values ('Adam',	'Bob',	'Giuseppe',	4,	1, 'testadmin@gmail.com',	'09987654321',	'admin',	'123',	'C:\',2)
insert into emp_info_main values ('John',	'Smith',	'Lockheed',	3,	1,	'johnsmith.l@gmail.com',	'09123456789',	'johnsmith',	'johnsmith123',	'C:\',2);
insert into emp_info_main values ('Joseph',	'Mann',	'Shepherd',	1, 2,	'joseph.g.shepherd@gmail.com',	'09561400909',	'joemann',	'joe123',	'C:\',2)
insert into emp_info_main values ('Matt',	'Stone',	'Roberts',	2,	2,	'mattstone@gmail.com',	'09564578915',	'mattstone',	'matt123',	'C:\',2)
insert into emp_info_main values ('Tommy',	'Hank',	'Ford',	4,	1,	't.ford@gmail.com',	'09866755488',	'tford',	'ford123',	'C:\',2)
insert into emp_info_main values ('Ramone',	'Paul',	'Simmons',	1,	2,	's.simmons@gmail.com',	'09684475826',	'steve.s',	'steve123',	'C:\',2)
select *from emp_info_main

create table EmpRoles (id int identity (1,1) primary key, EmpRoles varchar(50))
insert into EmpRoles values('Administrator')
insert into EmpRoles values('Staff')
select *from EmpRoles


create table EmpStatus(id int identity (1,1) primary key, ActiveStatus varchar(50))
insert into EmpStatus values('Active')
insert into EmpStatus values('Inactive')
select *from EmpStatus


create table EmpPosition (id int identity (1,1) primary key, Position varchar(50))
insert into EmpPosition values('Librarian I')
insert into EmpPosition values('Librarian II')
insert into EmpPosition values('Librarian III')
insert into EmpPosition values('Librarian IV')
select *from EmpPosition

create table Test(id int identity (0,1), test varchar(10));
insert into test values('1')
insert into test values('2')
select *from Test;
drop table Test;


--select all administrator
SELECT emp.id, emp.FirstName, emp.MiddleName, emp.LastName, ep.Position, er.EmpRoles, emp.EMailAddress, emp.ContactNo, emp.Username, emp.Password, emp.ImgPath, es.ActiveStatus
FROM emp_info_main emp
INNER JOIN EmpRoles er
 ON(emp.EmpRoles = er.id)
 INNER JOIN EmpPosition ep
 ON(emp.Position = ep.id)
 INNER JOIN EmpStatus es
ON(emp.ActiveStatus = es.id)
 INNER JOIN EmpInfo es
ON(emp.ActiveStatus = es.id)
 where emp.EmpRoles = '1' 

--select specific admin
 SELECT emp.id, emp.FirstName, emp.MiddleName, emp.LastName, ep.Position, er.EmpRoles, emp.EMailAddress, emp.ContactNo, emp.Username, emp.Password, emp.ImgPath
FROM emp_info_main emp
INNER JOIN EmpRoles er
 ON(emp.EmpRoles = er.id)
 INNER JOIN EmpPosition ep
 ON(emp.Position = ep.id)
 where emp.EmpRoles = '1' and emp.username = 'admin' and emp.password = 'admin123'

--select all staff
SELECT emp.id, emp.FirstName, emp.MiddleName, emp.LastName, ep.Position, er.EmpRoles, emp.EMailAddress, emp.ContactNo, emp.Username, emp.Password, emp.ImgPath, es.ActiveStatus
FROM emp_info_main emp
INNER JOIN EmpRoles er
 ON(emp.EmpRoles = er.id)
 INNER JOIN EmpPosition ep
 ON(emp.Position = ep.id)
 INNER JOIN EmpStatus es
ON(emp.ActiveStatus = es.id)
 where emp.EmpRoles = '2' 

--select  inactive status
SELECT emp.id ,emp.FirstName, emp.MiddleName, emp.LastName, ep.Position, er.EmpRoles, emp.EMailAddress, emp.ContactNo, emp.Username, emp.Password, emp.ImgPath, es.ActiveStatus
FROM emp_info_main emp
INNER JOIN EmpRoles er
 ON(emp.EmpRoles = er.id)
INNER JOIN EmpPosition ep
 ON(emp.Position = ep.id)
INNER JOIN EmpStatus es
 ON(emp.ActiveStatus = es.id)
 where emp.ActiveStatus = '2'

--select  active status
SELECT emp.id ,emp.FirstName, emp.MiddleName, emp.LastName, ep.Position, er.EmpRoles, emp.EMailAddress, emp.ContactNo, emp.Username, emp.Password, emp.ImgPath, es.ActiveStatus
FROM emp_info_main emp
INNER JOIN EmpRoles er
 ON(emp.EmpRoles = er.id)
INNER JOIN EmpPosition ep
 ON(emp.Position = ep.id)
INNER JOIN EmpStatus es
 ON(emp.ActiveStatus = es.id)
 where emp.ActiveStatus = '2'

--create and insert dewey decimal table
create table DeweyDecimalClassification(id int identity (0,1) primary key,  DeweyDecimalRange varchar(500), DeweyDecimalGroup varchar(100))
insert into DeweyDecimalClassification values ('000-099', 'General Works');
insert into DeweyDecimalClassification values ('100�199', 'Philosophy and Psychology');
insert into DeweyDecimalClassification values ('200�299', 'Religion');
insert into DeweyDecimalClassification values ('300�399', 'Social Sciences');
insert into DeweyDecimalClassification values ('400�499', 'Language');
insert into DeweyDecimalClassification values ('500�599', 'Natural Sciences and Mathematics');
insert into DeweyDecimalClassification values ('600�699', 'Technology');
insert into DeweyDecimalClassification values ('700�799', 'Arts');
insert into DeweyDecimalClassification values ('800�899', 'Literature and Rhetoric ');
insert into DeweyDecimalClassification values ('900�999', 'History, Biography, and Geography');
select *from DeweyDecimalClassification

create table member_info_main (id int identity (1,1) primary key, FirstName varchar(100), MiddleName varchar(100), LastName varchar(100), SchoolOrOrganization varchar(10), Address varchar(100), EMailAddress varchar(100), ContactNo varchar(11), MemberStart datetime, MemberEnd datetime, ImgPath varchar(100));
create table memb_SchoolOrOrg (id int identity (1,1) primary key, SchoolOrOrganization varchar(10))

--compare and select same values
select *from memb_SchoolOrOrg where SchoolOrOrganization = '{searchinp}'

--if select *from memb_SchoolOrOrg =  false
insert into memb_SchoolOrOrg values ('{searchinp}');

SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'emp_info_main'
ORDER BY ORDINAL_POSITION

--insert into employee tables
insert into emp_info_main values ('{firstname}', '{middlename}','{lastname}','{position}', '{hieararchy}', '{email}','{contactno}','{username}', '{password}', '{imgpath}', '{ActiveStatus}')

--compare same username
select *from emp_info_main where username = '{username}'

--create and archive/insert entry on employee
create table archive_emp_info_main (id int identity (1,1) primary key, FirstName varchar(100), MiddleName varchar(100), LastName varchar(100), Position int, EmpRoles int, EMailAddress varchar(100), ContactNo varchar(11), username varchar(100), password varchar(100), ImgPath varchar(500), ActiveStatus varchar(10))
delete from emp_info_main where id = '{id}'
insert into archive_emp_info_main select FirstName,
MiddleName,
LastName,
Position,
EmpRoles,
EMailAddress,
ContactNo,
username,
password,
ImgPath,
ActiveStatus
from emp_info_main where emp_info_main.id = 9
drop table archive_emp_info_main
select *from archive_emp_info_main
delete from archive_emp_info_main where id = 2;

create table member_receipts (id int identity (1,1) primary key, ORNumber varchar(8), ORReceivedDate date)



 
 
 
 
 
 