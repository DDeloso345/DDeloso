﻿using System;

namespace Admin_BookInventorySQLTestClass
{
    public class Class1
    {
    }
}
